# Jenkins-Docker-Project


<h1> docker container run -itd --name mycont -p 9001:80  nginx <h1>

#Never put /bin/bash in last for ip forwarding
